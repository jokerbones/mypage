#!/bin/bash
n=1
data=`date | awk -F " " '{print $4" "$3"/"$2}'`
#hosts=`cat /home/dirceu/testeping/hosts.txt`
hosts=`mysql -h 172.20.0.1 -P 3306 --protocol=tcp -u sistema -pqwe123 -e "select * from sistema.clientes where ip <> '0.0.0.0';" | grep -v "0.0.0.0" |grep -v "escola" | awk -F " " '{print $1"#"$2"#"$3"#"$4"#"$5}'`
echo "<tr><td colspan=5 >$data</td></tr>"
echo "<tr><td style='background : #aaa'>ESCOLA</td><td width=35 style='background : #aaa'>STATUS</td><td style='background : #aaa'>LINK</td><td width=70  style='background : #aaa'>IP</td><td style='background : #aaa'>LOCAL</td>"
for a in $hosts ;do
		 host=`echo $a | awk -F '#' '{print $1}' `
		 ip=`echo $a | awk -F '#' '{print $2}' `
		 local=`echo $a | awk -F '#' '{print $3}' `
		 sts=`echo $a | awk -F '#' '{print $4}' `
		 link=`echo $a | awk -F '#' '{print $5}' `

# controles
#erro=<input type=button onclick="window.open('erros.php?host=teste','_blank','')">

#ips="<a href='com/analiza.php?ip=$ip' target=log  style='color: #000'>$ip</a> "
ips="<b>$ip</b> "
		
# variaveis
if  [ "$sts" = "Indefinido" ]; then 
status="<td width=100 style='background : #008;color:#fff;text-align : left ;'><center>Indefinido</td>"
fi

if  [ "$sts" = "SEDUC" ]; then 
status="<td width=100 style='background : #080;color:#fff;text-align : left ;'><center>SEDUC</td>"
fi

if  [ "$sts" = "outro" ]; then 
status="<td width=100 style='background : #c60;color:#000;text-align : left ;'><center>outro</td>"
fi


NULO="<tr><td style='background : #880;text-align : left><a href=logs/$host.velocidade.html target='_blank' style=' text-decoration : none; color: #333'>$n - $host</a></td><td style='background : #000'><center>NULL</td>$status<td style='background : #ccc'>---</td><td width=100 style='background : #ccc'>$local</td></tr>"
		
ON="<tr><td style='text-align : left ;'><a href=logs/$host.velocidade.html target='log' style=' text-decoration : none; color: #333'>$n - $host</a></td><td style='background : #080;color:#fff'><center>ON</td>$status<td style='background : #ccc'>$ips</td><td width=100 style='background : #ccc'>$local</td></tr>"

OFF="<tr><td style='background : #a33;color:#fff;text-align : left ;'><a href=logs/$host.velocidade.html target='log' style=' text-decoration : none;'>$n - $host</a></td><td style='background : #f00;color:#fff'><center>OFF</td>$status<td style='background : #ccc'>---</td><td width=100 style='background : #ccc'>$local</td></tr>"


	
			if [ "$link" = "ON" ] ; then	
			echo "$ON" 			
			fi
			
			if [ "$link" = "OFF" ] ; then 
			echo "$OFF"			
			fi
			
			n=$(($n+1))
		done


