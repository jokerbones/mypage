<?php
echo '<link href="estilo.css" rel="stylesheet">' ;
echo "<center><b>ESCOLAS NÃO CADASTRADAS :</b>" ;
echo "<table border=0 width=70%>" ;
system("sh listasemconexao.sh");
?>
