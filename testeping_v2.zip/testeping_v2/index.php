<title>TESTEPING-V0.2</title>
<link href="estilo.css" rel="stylesheet">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<body bgcolor=000000><font color=white><center>

<table border=0 width=98% height=98%>

<tr height=80><td style="background : #030;color:#ddd"><center><h1>MONITORAMENTO - LINKS DAS ESCOLAS - CREDE 05</h1><br>
<?php
#system('date');

?>
</td></tr>

<tr height=5><td style="background : #000;text-align :left">
<input type=button value="Monitoramento" onclick="window.open('testeping.php','pag1','')" style="background : #080;color:#fff">
<input type=button value="Logs de velocidade" onclick="window.open('/logs','pag1','')" style="background : #080;color:#fff">
<input type=button value="Maquinas sem cadastro" onclick="window.open('semcadastro.php','pag1','')" style="background : #080;color:#fff">

</td></tr>



<tr width=100% height=85%><td>
<iframe width=100% height=100% name="pag1" src="testeping.php" frameborder=0></iframe>
</td></tr>
<tr><td style="background : #030;color:#ddd">V 0.2 - Dockerserver</td></tr>
</table>
