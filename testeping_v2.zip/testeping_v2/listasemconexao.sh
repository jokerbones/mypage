hosts=`mysql -h 172.20.0.1 -P 3306 --protocol=tcp -u sistema -pqwe123 -e "select * from sistema.clientes;" | grep "0.0.0.0" |grep -v "escola" | awk -F " " '{print $1"#"$2"#"$3"#"$4}'`

n=1

echo "<tr><td style='background : #aaa'>ESCOLA</td><td style='background : #aaa'>LOCAL</td>"
for a in $hosts ;do
		 host=`echo $a | awk -F '#' '{print $1}' `
		 ip=`echo $a | awk -F '#' '{print $2}' `
		 local=`echo $a | awk -F '#' '{print $3}' `
		 sts=`echo $a | awk -F '#' '{print $4}' `


OFF="<tr><td style='background:#ccc;text-align : left ;'>$n - $host</td><td width=100 style='background : #ccc'>$local</td></tr>"
echo "$OFF"
n=$(($n+1))
done
