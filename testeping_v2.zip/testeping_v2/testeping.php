<head>
<title>TESTEPING</title>
<link href="estilo.css" rel="stylesheet">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor=dddddd><font color=white><center>

<table border=0 width=80%>

<tr><td colspan=4 >
<?php 

#system ("sh /var/www/html/testeping.sh") ; 
system ("sh /var/www/html/monitor.sh") ; 

?>
</td></tr>

</table>

</font>
</body>
<meta http-equiv="refresh" content="10">

