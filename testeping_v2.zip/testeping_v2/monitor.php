<?php
  	(echo "$ON"  || (echo "$OFF" 


?>